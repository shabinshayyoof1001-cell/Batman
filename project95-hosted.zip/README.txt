PROJECT 95 — HOSTED / INSTALLABLE PACKAGE
========================================

This folder is ready to publish as a static website. The checklist works without a backend.

PUBLISH ONCE (Android or computer)
1. Sign in to a free Netlify account at https://app.netlify.com/ (or create one).
2. Open https://app.netlify.com/drop
3. Upload the ZIP package you downloaded in this chat.
4. Wait for Netlify to publish it. Open the resulting *.netlify.app URL.
5. Keep this same site and URL. Save/bookmark the URL so you can return to it.

INSTALL ON ANDROID
1. Open the published site URL in Chrome.
2. Tap Chrome's three-dot menu (⋮).
3. Choose "Install app" or "Add to Home screen" and follow the prompt.
4. Open PROJECT 95 from the home-screen icon. After first successful load, the app shell is cached for offline opening.

PROGRESS & SAFETY
- Checkboxes auto-save in this browser's local storage.
- Keep using the same Chrome profile and the same site URL.
- Do not clear Chrome's site data for this website; doing so can erase saved checkboxes.
- Progress is local to this browser/device. It does not synchronize between phones or browsers.
- The page's HTML/CSS/data can be updated and redeployed to the EXISTING Netlify site. Deploying to the same URL keeps the same browser storage origin, so checkbox progress normally remains.
- If you create a new Netlify site or change domains, browser storage will be separate and the checklist may look reset.
- If hosting a new version, upload the unzipped site's files (including index.html, manifest.webmanifest, sw.js, and icons/). The host must serve over HTTPS for offline and install support.

EDITABLE DATA
Open index.html in a code editor and find the line starting with:
  const CHAPTERS = ...
Durations are stored as integer minutes. Redeploy the updated site to the same hosted site for code/data changes.
